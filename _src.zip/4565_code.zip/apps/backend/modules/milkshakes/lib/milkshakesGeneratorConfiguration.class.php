<?php

/**
 * milkshakes module configuration.
 *
 * @package    milkshake
 * @subpackage milkshakes
 * @author     Your name here
 * @version    SVN: $Id: configuration.php 12474 2008-10-31 10:41:27Z fabien $
 */
class milkshakesGeneratorConfiguration extends BaseMilkshakesGeneratorConfiguration
{
}
