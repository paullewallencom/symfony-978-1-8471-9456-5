<?php

require_once dirname(__FILE__).'/../lib/milkshakesGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/milkshakesGeneratorHelper.class.php';

/**
 * milkshakes actions.
 *
 * @package    milkshake
 * @subpackage milkshakes
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class milkshakesActions extends autoMilkshakesActions
{
}
