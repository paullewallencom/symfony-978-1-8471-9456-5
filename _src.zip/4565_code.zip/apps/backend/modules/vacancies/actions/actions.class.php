<?php

require_once dirname(__FILE__).'/../lib/vacanciesGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/vacanciesGeneratorHelper.class.php';

/**
 * vacancies actions.
 *
 * @package    milkshake
 * @subpackage vacancies
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class vacanciesActions extends autoVacanciesActions
{
}
