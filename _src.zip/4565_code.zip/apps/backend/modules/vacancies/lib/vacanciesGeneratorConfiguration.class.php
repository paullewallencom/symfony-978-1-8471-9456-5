<?php

/**
 * vacancies module configuration.
 *
 * @package    milkshake
 * @subpackage vacancies
 * @author     Your name here
 * @version    SVN: $Id: configuration.php 12474 2008-10-31 10:41:27Z fabien $
 */
class vacanciesGeneratorConfiguration extends BaseVacanciesGeneratorConfiguration
{
}
