<?php

require_once dirname(__FILE__).'/../lib/store_locationGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/store_locationGeneratorHelper.class.php';

/**
 * store_location actions.
 *
 * @package    milkshake
 * @subpackage store_location
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 12474 2008-10-31 10:41:27Z fabien $
 */
class store_locationActions extends autoStore_locationActions
{
}
