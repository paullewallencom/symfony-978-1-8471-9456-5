<?php

class MilkshakeFlavor extends BaseMilkshakeFlavor
{
}
