<?php

class Vacancy extends BaseVacancy
{
}
