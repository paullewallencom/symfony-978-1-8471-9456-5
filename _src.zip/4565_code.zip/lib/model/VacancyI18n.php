<?php

class VacancyI18n extends BaseVacancyI18n
{
}
