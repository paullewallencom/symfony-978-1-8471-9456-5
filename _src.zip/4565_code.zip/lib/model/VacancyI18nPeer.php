<?php

class VacancyI18nPeer extends BaseVacancyI18nPeer
{
}
