<?php

class FlavorPeer extends BaseFlavorPeer
{
}
