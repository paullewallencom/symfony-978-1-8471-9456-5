<?php

class AlSignupNewsletterSignupPeer extends BaseAlSignupNewsletterSignupPeer
{
}
