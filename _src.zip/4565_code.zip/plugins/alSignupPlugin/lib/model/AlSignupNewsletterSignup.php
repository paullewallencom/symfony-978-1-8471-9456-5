<?php

class AlSignupNewsletterSignup extends BaseAlSignupNewsletterSignup
{
}
