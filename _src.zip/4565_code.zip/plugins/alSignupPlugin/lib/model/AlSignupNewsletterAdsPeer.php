<?php

class AlSignupNewsletterAdsPeer extends BaseAlSignupNewsletterAdsPeer
{
}
