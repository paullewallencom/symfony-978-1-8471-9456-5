Hi <?php echo $name; ?>, <br /><br />
Thank you for signing up to our newsletter.

<br /><br />
Thank you,
<br />
<strong>The Team</strong>