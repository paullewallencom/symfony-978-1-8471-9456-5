<?php

/**
 * sfGuardGroupPermission form.
 *
 * @package    form
 * @subpackage sf_guard_group_permission
 * @version    SVN: $Id: sfGuardGroupPermissionForm.class.php 9999 2008-06-29 21:24:44Z fabien $
 */
class sfGuardGroupPermissionForm extends BasesfGuardGroupPermissionForm
{
  public function configure()
  {
  }
}
