<?php

/**
 * sfGuardUserGroup form.
 *
 * @package    form
 * @subpackage sf_guard_user_group
 * @version    SVN: $Id: sfGuardUserGroupForm.class.php 9999 2008-06-29 21:24:44Z fabien $
 */
class sfGuardUserGroupForm extends BasesfGuardUserGroupForm
{
  public function configure()
  {
  }
}
