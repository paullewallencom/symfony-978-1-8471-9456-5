<?php

/**
 * sfGuardRememberKey form.
 *
 * @package    form
 * @subpackage sf_guard_remember_key
 * @version    SVN: $Id: sfGuardRememberKeyForm.class.php 9999 2008-06-29 21:24:44Z fabien $
 */
class sfGuardRememberKeyForm extends BasesfGuardRememberKeyForm
{
  public function configure()
  {
  }
}
