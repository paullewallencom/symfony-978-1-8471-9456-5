<?php

require_once dirname(__FILE__).'/../lib/Base##MODULE_NAME##Actions.class.php';

/**
 * ##MODULE_NAME## actions.
 * 
 * @package    ##PLUGIN_NAME##
 * @subpackage ##MODULE_NAME##
 * @author     ##AUTHOR_NAME##
 * @version    SVN: $Id: actions.class.php 12628 2008-11-04 14:43:36Z Kris.Wallsmith $
 */
class ##MODULE_NAME##Actions extends Base##MODULE_NAME##Actions
{
}
