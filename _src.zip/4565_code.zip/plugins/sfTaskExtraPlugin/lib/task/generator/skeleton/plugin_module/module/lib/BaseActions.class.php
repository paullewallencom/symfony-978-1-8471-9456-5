<?php

/**
 * Base actions for the ##PLUGIN_NAME## ##MODULE_NAME## module.
 * 
 * @package     ##PLUGIN_NAME##
 * @subpackage  ##MODULE_NAME##
 * @author      ##AUTHOR_NAME##
 * @version     SVN: $Id: BaseActions.class.php 12628 2008-11-04 14:43:36Z Kris.Wallsmith $
 */
abstract class Base##MODULE_NAME##Actions extends sfActions
{
}
