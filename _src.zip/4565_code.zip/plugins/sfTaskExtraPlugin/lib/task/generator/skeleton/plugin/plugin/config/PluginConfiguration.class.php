<?php

/**
 * ##PLUGIN_NAME## configuration.
 * 
 * @package     ##PLUGIN_NAME##
 * @subpackage  config
 * @author      ##AUTHOR_NAME##
 * @version     SVN: $Id: PluginConfiguration.class.php 12675 2008-11-06 08:07:42Z Kris.Wallsmith $
 */
class ##PLUGIN_NAME##Configuration extends sfPluginConfiguration
{
  /**
   * @see sfPluginConfiguration
   */
  public function initialize()
  {
  }
}
